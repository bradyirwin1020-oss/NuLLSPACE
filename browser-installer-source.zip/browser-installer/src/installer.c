/* SPDX-License-Identifier: GPL-3.0-or-later
 * Haze browser installer candidate, 2026.
 * Fresh, one-shot ELF process. Never send PKGs to an ELF loader.
 * Firmware identity approach informed by MIT-licensed BFpilot; see THIRD_PARTY.md.
 */
#include <arpa/inet.h>
#include <curl/curl.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <netinet/in.h>
#include <openssl/evp.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <ps5/kernel.h>
#include "appinst_abi.h"
#include "generated_config.h"

#define ROOT_DIR "/user/data/HazeBrowserInstaller"
#define TITLE_ID HAZE_TITLE_ID
#define CONTENT_ID HAZE_CONTENT_ID
#define PACKAGE_BYTES HAZE_PACKAGE_BYTES
#define PACKAGE_SHA256 HAZE_PACKAGE_SHA256
#define SUPPORTED_FW UINT32_C(0x13420000)
#define INSTALL_AUTHID UINT64_C(0x4801000000000013)
#define READY_TIMEOUT_SECONDS 90
#define INSTALL_TIMEOUT_SECONDS 180
#define PENDING_PATH ROOT_DIR "/pending-" TITLE_ID ".json"

/* Official SDK v0.43 samples/notify_debug/main.c documents this kernel ABI.
 * Copyright (C) 2023 John Tornblom; GPL-3.0-or-later. See THIRD_PARTY.md.
 */
typedef struct { char prefix[45]; char message[3075]; } KernelNotification;
_Static_assert(sizeof(KernelNotification) == 3120, "notification ABI");
_Static_assert(offsetof(KernelNotification, message) == 45, "notification message ABI");
int sceKernelSendNotificationRequest(int, KernelNotification *, size_t, int);

static char run_dir[256], package_path[320];
static int lock_fd = -1;
static uint64_t monotonic_ms(void) {
  struct timespec ts;
  if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) _exit(20);
  return (uint64_t)ts.tv_sec * 1000 + (uint64_t)ts.tv_nsec / 1000000;
}

/* States and messages are fixed strings: no URL/token or package metadata is logged. */
static void report(const char *state, const char *message, int rc) {
  printf("[HazeBrowserInstaller] %s: %s (0x%08x)\n", state, message, (unsigned)rc);
  fflush(stdout);
  if (strcmp(state, "ready") && strcmp(state, "submitting")) {
    KernelNotification notification = {0};
    snprintf(notification.message, sizeof(notification.message), "Haze browser installer\n%s (0x%08x)", message, (unsigned)rc);
    (void)sceKernelSendNotificationRequest(0, &notification, sizeof(notification), 0);
  }
  if (!run_dir[0]) return;
  char temp[320];
  snprintf(temp, sizeof(temp), "%s/status.tmp", run_dir);
  int fd = open(temp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
  if (fd < 0) return;
  FILE *f = fdopen(fd, "w");
  if (!f) { close(fd); unlink(temp); return; }
  fprintf(f, "{\"state\":\"%s\",\"message\":\"%s\",\"code\":%d,\"titleId\":\"%s\"}\n",
          state, message, rc, TITLE_ID);
  int ok = fflush(f) == 0 && fsync(fd) == 0;
  if (fclose(f) != 0) ok = 0;
  if (ok) (void)rename(temp, ROOT_DIR "/status.json");
  else (void)unlink(temp);
}
static int directory_checked(const char *path) {
  if (mkdir(path, 0700) != 0 && errno != EEXIST) return -errno;
  struct stat st;
  if (lstat(path, &st) != 0 || !S_ISDIR(st.st_mode)) return -ENOTDIR;
  return 0;
}
static int setup_staging(void) {
  int rc = directory_checked(ROOT_DIR);
  if (rc) return rc;
  lock_fd = open(ROOT_DIR "/installer.lock", O_WRONLY | O_CREAT | O_NOFOLLOW, 0600);
  if (lock_fd < 0) return -errno;
  if (flock(lock_fd, LOCK_EX | LOCK_NB) != 0) return -errno;
  snprintf(run_dir, sizeof(run_dir), ROOT_DIR "/run-XXXXXX");
  if (!mkdtemp(run_dir)) { run_dir[0] = 0; return -errno; }
  snprintf(package_path, sizeof(package_path), "%s/Browser.pkg", run_dir);
  return 0;
}
static bool pending_marker_present(void) {
  struct stat st;
  return lstat(PENDING_PATH, &st) == 0;
}
/* Persist intent before submitting to an asynchronous service. A process lock
 * alone cannot protect a subsequent visit after this process times out/exits.
 */
static int create_pending_marker(void) {
  int fd = open(PENDING_PATH, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
  if (fd < 0) return -errno;
  FILE *f = fdopen(fd, "w");
  if (!f) { int rc = -errno; close(fd); unlink(PENDING_PATH); return rc; }
  int ok = fprintf(f, "{\"state\":\"submission_intent\",\"titleId\":\"%s\",\"contentId\":\"%s\",\"packagePath\":\"%s\"}\n",
                   TITLE_ID, CONTENT_ID, package_path) > 0;
  if (fflush(f) != 0 || fsync(fd) != 0) ok = 0;
  if (fclose(f) != 0) ok = 0;
  if (!ok) { unlink(PENDING_PATH); return -EIO; } /* No submission was made. */
  fd = open(ROOT_DIR, O_RDONLY | O_DIRECTORY | O_NOFOLLOW);
  if (fd < 0) return -errno; /* Retain marker; no submission made. */
  int rc = fsync(fd) == 0 ? 0 : -errno;
  close(fd);
  return rc;
}
static void clear_confirmed_pending_marker(void) {
  if (unlink(PENDING_PATH) == 0) {
    int fd = open(ROOT_DIR, O_RDONLY | O_DIRECTORY | O_NOFOLLOW);
    if (fd >= 0) { (void)fsync(fd); close(fd); }
  }
}

static bool ready_process(const char *marker, const char *expected_name) {
  int fd = open(marker, O_RDONLY | O_NOFOLLOW);
  if (fd < 0) return false;
  char text[48] = {0}, name[64] = {0};
  ssize_t count = read(fd, text, sizeof(text) - 1);
  close(fd);
  if (count <= 0 || count == (ssize_t)sizeof(text) - 1) return false;
  char *end;
  errno = 0;
  long pid = strtol(text, &end, 10);
  while (*end == '\r' || *end == '\n') ++end;
  return !errno && *end == 0 && pid > 1 && pid <= INT_MAX &&
         kill((pid_t)pid, 0) == 0 && sceKernelGetProcessName((int)pid, name) == 0 &&
         strcmp(name, expected_name) == 0;
}
/* A TCP connection alone does not establish loader health. Require its exact reply. */
static bool loader_ping(void) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd < 0) return false;
  if (fcntl(fd, F_SETFL, O_NONBLOCK) < 0) { close(fd); return false; }
  struct sockaddr_in addr = {0};
  addr.sin_family = AF_INET;
  addr.sin_port = htons(9020);
  addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int rc = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
  struct pollfd p = {.fd = fd, .events = POLLOUT};
  int err = 0; socklen_t err_len = sizeof(err);
  if ((rc != 0 && errno != EINPROGRESS) || poll(&p, 1, 800) <= 0 ||
      getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &err_len) != 0 || err != 0) {
    close(fd); return false;
  }
  const char request[] = "hen:ping\n";
  size_t sent = 0, received = 0;
  char response[64] = {0};
  uint64_t deadline = monotonic_ms() + 1200;
  while (sent < sizeof(request) - 1 && monotonic_ms() < deadline) {
    p.events = POLLOUT;
    if (poll(&p, 1, 100) <= 0) continue;
    ssize_t n = send(fd, request + sent, sizeof(request) - 1 - sent, 0);
    if (n > 0) sent += (size_t)n;
    else if (n == 0 || (errno != EAGAIN && errno != EINTR)) break;
  }
  while (sent == sizeof(request) - 1 && received < sizeof(response) - 1 && monotonic_ms() < deadline) {
    p.events = POLLIN;
    if (poll(&p, 1, 100) <= 0) continue;
    ssize_t n = recv(fd, response + received, sizeof(response) - 1 - received, 0);
    if (n > 0) { received += (size_t)n; if (memchr(response, '\n', received)) break; }
    else if (n == 0 || (errno != EAGAIN && errno != EINTR)) break;
  }
  close(fd);
  return strcmp(response, "OK hen_elfldr 9020\n") == 0;
}
static bool etahen_ready(void) {
  return ready_process("/system_tmp/etaHEN/ready/daemon", "hen_daemon.elf") &&
         ready_process("/system_tmp/etaHEN/ready/util", "hen_util.elf") && loader_ping();
}
static bool wait_ready(void) {
  uint64_t deadline = monotonic_ms() + READY_TIMEOUT_SECONDS * 1000;
  while (monotonic_ms() < deadline) {
    if (etahen_ready()) return true;
    usleep(500000);
  }
  return false;
}

/* Conservative fast skip before waiting or changing identity. The directory may
 * also belong to a partially installed title, so this message claims file
 * presence, not Sony registration. Native AppExists remains the authoritative
 * fallback for titles on other storage. Never overwrite an existing title.
 */
static bool browser_files_present(void) {
  struct stat st;
  return lstat("/user/app/" TITLE_ID, &st) == 0 && S_ISDIR(st.st_mode);
}

/* Only this fresh worker's identity changes, before its first AppInst IPC call.
 * Every write is checked. Unknown firmware never reaches this function.
 */
static int install_identity(void) {
  pid_t pid = getpid();
  intptr_t root = kernel_get_root_vnode();
  uint8_t caps[16], attrs[32] = {0}, verify[32];
  memset(caps, 0xff, sizeof(caps)); attrs[0] = 0x80;
  if (pid <= 1 || !kernel_get_proc(pid) || !root) return -ENOTSUP;
  if (kernel_set_ucred_uid(pid, 0) || kernel_set_ucred_ruid(pid, 0) ||
      kernel_set_ucred_svuid(pid, 0) || kernel_set_ucred_rgid(pid, 0) ||
      kernel_set_ucred_svgid(pid, 0) || kernel_set_proc_rootdir(pid, root) ||
      kernel_set_proc_jaildir(pid, root) || kernel_set_ucred_authid(pid, INSTALL_AUTHID) ||
      kernel_set_ucred_caps(pid, caps) || kernel_set_ucred_attrs(pid, attrs)) return -EIO;
  if (kernel_get_ucred_authid(pid) != INSTALL_AUTHID || kernel_get_ucred_uid(pid) != 0 ||
      kernel_get_proc_rootdir(pid) != root || kernel_get_proc_jaildir(pid) != root ||
      kernel_get_ucred_caps(pid, verify) || memcmp(verify, caps, sizeof(caps)) ||
      kernel_get_ucred_attrs(pid, verify) || memcmp(verify, attrs, sizeof(attrs))) return -EIO;
  return 0;
}

/* Native IPC can hang. A separate thread lets this process bound each call.
 * On timeout the process exits; it never issues a duplicate submission or
 * removes a file that an indeterminate/background installation might use.
 */
enum Operation { OP_INIT, OP_EXISTS, OP_SUBMIT, OP_STATUS };
static struct {
  enum Operation operation;
  atomic_int done, rc;
  int exists;
  InstallMetadata metadata;
  InstallPackageInfo info;
  InstallPlayGo playgo;
  InstallStatus status;
} call;
static void *native_call(void *unused) {
  (void)unused;
  int rc;
  switch (call.operation) {
    case OP_INIT: rc = sceAppInstUtilInitialize(); break;
    case OP_EXISTS: rc = sceAppInstUtilAppExists(TITLE_ID, &call.exists); break;
    case OP_SUBMIT: rc = sceAppInstUtilInstallByPackage(&call.metadata, &call.info, &call.playgo); break;
    case OP_STATUS: rc = sceAppInstUtilGetInstallStatus(CONTENT_ID, &call.status); break;
    default: rc = -EINVAL;
  }
  atomic_store_explicit(&call.rc, rc, memory_order_relaxed);
  atomic_store_explicit(&call.done, 1, memory_order_release);
  return NULL;
}
static int bounded_native(enum Operation operation, unsigned seconds, bool may_be_accepted) {
  call.operation = operation;
  atomic_store_explicit(&call.done, 0, memory_order_relaxed);
  pthread_t thread;
  int rc = pthread_create(&thread, NULL, native_call, NULL);
  if (rc) return -rc;
  rc = pthread_detach(thread);
  if (rc) {
    report(may_be_accepted ? "indeterminate" : "stopped",
           "Native worker thread could not be detached. Stopping without another submission.", -rc);
    _exit(may_be_accepted ? 2 : 1);
  }
  uint64_t deadline = monotonic_ms() + seconds * 1000;
  while (!atomic_load_explicit(&call.done, memory_order_acquire)) {
    if (monotonic_ms() >= deadline) {
      report(may_be_accepted ? "indeterminate" : "stopped",
             may_be_accepted ? "Native call timed out; installation may continue. Package retained. Do not resubmit." :
                               "Native initialization/query timed out. No package submitted.", -ETIMEDOUT);
      _exit(may_be_accepted ? 2 : 1);
    }
    usleep(100000);
  }
  return atomic_load_explicit(&call.rc, memory_order_relaxed);
}

struct Download { FILE *file; EVP_MD_CTX *digest; uint64_t received; unsigned char magic[4]; };
static size_t receive_package(char *data, size_t size, size_t count, void *context) {
  struct Download *d = context;
  if (size != 0 && count > SIZE_MAX / size) return 0;
  size_t n = size * count;
  if (n > PACKAGE_BYTES - d->received) return 0;
  if (d->received < 4) {
    size_t take = 4 - (size_t)d->received;
    if (take > n) take = n;
    memcpy(d->magic + d->received, data, take);
  }
  if (EVP_DigestUpdate(d->digest, data, n) != 1 || fwrite(data, 1, n, d->file) != n) return 0;
  d->received += n;
  return n;
}
#define SETOPT(option, value) do { if (curl_easy_setopt(curl, option, value) != CURLE_OK) goto failed; } while (0)
static int download_verified(void) {
  char part[336]; snprintf(part, sizeof(part), "%s.part", package_path);
  int fd = open(part, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
  if (fd < 0) return -errno;
  struct Download d = {0};
  d.file = fdopen(fd, "wb");
  if (!d.file) { close(fd); unlink(part); return -errno; }
  d.digest = EVP_MD_CTX_new();
  CURL *curl = NULL;
  int result = -EIO;
  if (!d.digest || EVP_DigestInit_ex(d.digest, EVP_sha256(), NULL) != 1) goto failed;
  curl = curl_easy_init();
  if (!curl) goto failed;
  struct curl_blob trust = {.data = (void *)haze_ca_bundle, .len = sizeof(haze_ca_bundle) - 1, .flags = CURL_BLOB_COPY};
  SETOPT(CURLOPT_URL, HAZE_PACKAGE_URL);
  SETOPT(CURLOPT_CAINFO_BLOB, &trust);
  SETOPT(CURLOPT_SSL_VERIFYPEER, 1L);
  SETOPT(CURLOPT_SSL_VERIFYHOST, 2L);
  SETOPT(CURLOPT_PROTOCOLS_STR, "https");
  SETOPT(CURLOPT_REDIR_PROTOCOLS_STR, "https");
  SETOPT(CURLOPT_FOLLOWLOCATION, 1L);
  SETOPT(CURLOPT_MAXREDIRS, 3L);
  SETOPT(CURLOPT_FAILONERROR, 1L);
  SETOPT(CURLOPT_CONNECTTIMEOUT, 15L);
  SETOPT(CURLOPT_TIMEOUT, 300L);
  SETOPT(CURLOPT_LOW_SPEED_LIMIT, 1024L);
  SETOPT(CURLOPT_LOW_SPEED_TIME, 30L);
  SETOPT(CURLOPT_NOSIGNAL, 1L);
  SETOPT(CURLOPT_WRITEFUNCTION, receive_package);
  SETOPT(CURLOPT_WRITEDATA, &d);
  SETOPT(CURLOPT_USERAGENT, "HazeBrowserInstaller/0.1-candidate");
  if (curl_easy_perform(curl) != CURLE_OK || d.received != PACKAGE_BYTES ||
      memcmp(d.magic, "\x7f" "FIH", 4) != 0) goto failed;
  unsigned char digest[EVP_MAX_MD_SIZE]; unsigned length = 0;
  char hex[65];
  if (EVP_DigestFinal_ex(d.digest, digest, &length) != 1 || length != 32) goto failed;
  for (unsigned i = 0; i < 32; ++i) snprintf(hex + i * 2, 3, "%02x", digest[i]);
  if (strcmp(hex, PACKAGE_SHA256) != 0 || fflush(d.file) != 0 || fsync(fd) != 0) goto failed;
  if (fclose(d.file) != 0) { d.file = NULL; goto failed; }
  d.file = NULL;
  if (rename(part, package_path) != 0) goto failed;
  result = 0;
failed:
  if (curl) curl_easy_cleanup(curl);
  if (d.digest) EVP_MD_CTX_free(d.digest);
  if (d.file) fclose(d.file);
  if (result) unlink(part); /* Only the new file created by this run. */
  return result;
}

int main(void) {
  (void)signal(SIGPIPE, SIG_IGN);
  /* SDK reads libc's SDK version, which may identify a firmware family. This
   * candidate only accepts the explicit 0x1342 SDK entry; it may conservatively
   * reject a 13.42 console whose libc instead reports the 0x1340 family entry.
   * A failed gate does not broaden support or change any kernel state.
   */
  uint32_t firmware = kernel_get_fw_version();
  if ((firmware & UINT32_C(0xffff0000)) != SUPPORTED_FW) {
    report("unsupported", "Unknown or unsupported firmware. No installer calls made.", (int)firmware); return 1;
  }
  if (browser_files_present()) {
    report("existing_browser_files", "Browser title " TITLE_ID " files already exist; skipped without installer calls.", 0); return 0;
  }
  if (pending_marker_present()) {
    report("pending_previous_attempt", "A prior browser submission is unresolved. Check console installation; no automatic retry.", -EALREADY); return 2;
  }
  if (!wait_ready()) { report("stopped", "etaHEN daemon/util and private loader did not become ready. No install attempted.", -ETIMEDOUT); return 1; }
  int rc = install_identity();
  if (rc) { report("stopped", "Worker installer identity could not be verified.", rc); return 1; }
  rc = setup_staging();
  if (rc) { report("stopped", "Staging unavailable or another installer is running.", rc); return 1; }
  report("ready", "etaHEN readiness and firmware checks passed.", 0);
  rc = bounded_native(OP_INIT, 10, false);
  if (rc) { report("stopped", "AppInst initialization failed. No package submitted.", rc); return 1; }
  rc = bounded_native(OP_EXISTS, 5, false);
  if (rc) { report("stopped", "Could not query existing browser. No install attempted.", rc); return 1; }
  if (call.exists) { report("already_installed", "Browser " TITLE_ID " is already installed; skipped.", 0); return 0; }
  if (strncmp(HAZE_PACKAGE_URL, "https://", 8) != 0 || !HAZE_PACKAGE_URL[8]) {
    report("stopped", "No HTTPS package URL configured.", -EINVAL); return 1;
  }
  if (curl_global_init(CURL_GLOBAL_DEFAULT) != CURLE_OK) {
    report("stopped", "HTTPS library initialization failed.", -EIO); return 1;
  }
  report("downloading", "Downloading browser package with certificate verification.", 0);
  rc = download_verified();
  curl_global_cleanup();
  if (rc) { report("stopped", "Download, exact size, FIH magic, or SHA256 check failed. No package submitted.", rc); return 1; }
  if (!etahen_ready()) { report("stopped", "etaHEN readiness was lost. Verified package retained; no submission.", -EAGAIN); return 1; }
  /* Recheck in case another installer installed the browser during the download. */
  rc = bounded_native(OP_EXISTS, 5, false);
  if (rc || call.exists) {
    report(rc ? "stopped" : "already_installed", rc ? "Existing browser recheck failed. No submission." : "Browser appeared during download; skipped.", rc);
    return rc ? 1 : 0;
  }
  call.metadata = (InstallMetadata){package_path, "", "", "", HAZE_DISPLAY_NAME, ""};
  memset(&call.info, 0, sizeof(call.info)); memset(&call.playgo, 0, sizeof(call.playgo));
  rc = create_pending_marker();
  if (rc) { report("stopped", "Could not persist exclusive submission intent. No package submitted.", rc); return 1; }
  report("submitting", "Submitting verified local package to native AppInst.", 0);
  rc = bounded_native(OP_SUBMIT, 15, true);
  if (rc) { report("rejected", "Native installer rejected submission; package retained.", rc); return 1; }
  if (!memchr(call.info.content_id, 0, sizeof(call.info.content_id)) || strcmp(call.info.content_id, CONTENT_ID) != 0) {
    report("indeterminate", "Submission accepted but returned content ID differs. Package retained; check console.", -EINVAL); return 2;
  }
  report("accepted", "Native installer accepted the browser package; completion is not yet confirmed.", 0);
  uint64_t deadline = monotonic_ms() + INSTALL_TIMEOUT_SECONDS * 1000;
  while (monotonic_ms() < deadline) {
    memset(&call.status, 0, sizeof(call.status));
    rc = bounded_native(OP_STATUS, 5, true);
    if (rc) { report("indeterminate", "Accepted package status could not be queried. Package retained; check console.", rc); return 2; }
    if (!memchr(call.status.status, 0, sizeof(call.status.status))) {
      report("indeterminate", "Invalid native status response. Package retained.", -EIO); return 2;
    }
    if (!strcmp(call.status.status, "playable")) {
      rc = bounded_native(OP_EXISTS, 5, true);
      if (!rc && call.exists) {
        clear_confirmed_pending_marker();
        report("playable", "Native installer reports browser playable and title exists. Open it from the home screen.", 0);
        /* Playable is not a guarantee that no background service references the
         * package. Keep it even on this result; cleanup must be a separate act. */
        return 0;
      }
      report("indeterminate", "Installer reports playable but browser existence could not be confirmed. Package retained.", rc ? rc : -ENOENT); return 2;
    }
    if (!strcmp(call.status.status, "error") || !strcmp(call.status.status, "none")) {
      report("failed", "Native installer reports a terminal error or no task. Package retained.", call.status.error_info.error_code); return 1;
    }
    usleep(500000);
  }
  report("accepted_pending", "Submission accepted; completion timeout reached. Package retained. Check console before retrying.", -ETIMEDOUT);
  return 2;
}
