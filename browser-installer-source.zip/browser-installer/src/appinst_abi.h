/* SPDX-License-Identifier: GPL-3.0-or-later
 * Native layouts documented by LightningMods / etaHEN's PS5 PKG writeup.
 * See THIRD_PARTY.md. No Sony SDK header is redistributed here.
 */
#ifndef HAZE_APPINST_ABI_H
#define HAZE_APPINST_ABI_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
  char content_id[48];
  int32_t content_type;
  int32_t content_platform;
} InstallPackageInfo;
typedef struct {
  const char *uri, *ex_uri, *playgo_scenario_id;
  const char *content_id, *content_name, *icon_url;
} InstallMetadata;
typedef struct {
  char languages[30][8];
  char playgo_scenario_ids[64][3];
  char content_ids[64][48];
  unsigned char reserved[6480];
} InstallPlayGo;
typedef struct {
  int32_t error_code, version;
  char description[512], type[9];
} InstallError;
typedef struct {
  char status[16], src_type[8];
  uint32_t remain_time;
  uint64_t downloaded_size, initial_chunk_size, total_size;
  uint32_t promote_progress;
  InstallError error_info;
  int32_t local_copy_percent;
  bool is_copy_only;
} InstallStatus;

_Static_assert(sizeof(void *) == 8, "PS5 x86-64 ABI required");
_Static_assert(sizeof(InstallMetadata) == 48, "metadata ABI");
_Static_assert(sizeof(InstallPackageInfo) == 56, "package info ABI");
_Static_assert(sizeof(InstallPlayGo) == 9984, "PlayGo ABI");
_Static_assert(sizeof(InstallError) == 532, "error ABI");
_Static_assert(sizeof(InstallStatus) == 600, "status ABI");
_Static_assert(offsetof(InstallStatus, downloaded_size) == 32, "status alignment");
_Static_assert(offsetof(InstallStatus, error_info) == 60, "status error alignment");

int sceAppInstUtilInitialize(void);
int sceAppInstUtilAppExists(const char *title_id, int *exists);
int sceAppInstUtilInstallByPackage(const InstallMetadata *, InstallPackageInfo *, InstallPlayGo *);
int sceAppInstUtilGetInstallStatus(const char *content_id, InstallStatus *);
int sceKernelGetProcessName(int pid, char *name);
#endif
