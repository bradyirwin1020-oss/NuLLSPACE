#!/usr/bin/env python3
"""Host checks only: configuration validation, ABI arithmetic, optional local package hash."""
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse
import ctypes as c
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("candidate_configure", ROOT / "configure.py")
config = importlib.util.module_from_spec(spec)
spec.loader.exec_module(config)

class Error(c.Structure):
    _fields_ = [("error_code", c.c_int32), ("version", c.c_int32), ("description", c.c_char * 512), ("type", c.c_char * 9)]
class Status(c.Structure):
    _fields_ = [("status", c.c_char * 16), ("src_type", c.c_char * 8), ("remain_time", c.c_uint32),
                ("downloaded_size", c.c_uint64), ("initial_chunk_size", c.c_uint64), ("total_size", c.c_uint64),
                ("promote_progress", c.c_uint32), ("error_info", Error), ("local_copy_percent", c.c_int32), ("is_copy_only", c.c_bool)]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path)
    args = parser.parse_args()
    valid = "https://example.invalid/InternetBrowser-PS5M.pkg"
    assert config.validate_url(valid) == valid
    for invalid in ["", "http://example.invalid/a.pkg", "https://u:p@example.invalid/a.pkg", "https://example.invalid/a#fragment", "https://example.invalid/a\n", "https://example.invalid:abc/a"]:
        try:
            config.validate_url(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Invalid URL accepted: {invalid!r}")
    try:
        config.render_config(valid, b"not a trust bundle")
    except ValueError:
        pass
    else:
        raise AssertionError("Non-PEM CA bundle accepted")
    # Placeholder PEM tests escaping only; it is never written to a build config.
    rendered = config.render_config(valid, b"-----BEGIN CERTIFICATE-----\nABC\n-----END CERTIFICATE-----\n")
    assert '\\n"' in rendered and valid in rendered
    original = config.load_manifest()
    assert original["titleId"] == "MOUU12023"
    assert original["sha256"] == "90d29db230458acfd2e3332dc338afe6e63f3d0c0948517918286497c9ac17ca"
    for key, invalid_value in [("size", True), ("size", 0), ("size", 100000000), ("sha256", 4),
                               ("titleId", "../escape"), ("contentId", "IV9999-HAZE00001_00-XXXXXXXXXXXXXXXX"),
                               ("displayName", "name\n")]:
        bad = {**original, key: invalid_value}
        try:
            config.validate_manifest(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Invalid manifest accepted: {key}")
    custom = {**original, "titleId": "HAZE00001", "contentId": "IV9999-HAZE00001_00-XXXXXXXXXXXXXXXX"}
    config.validate_manifest(custom)
    custom_render = config.render_config(valid, b"-----BEGIN CERTIFICATE-----\nABC\n-----END CERTIFICATE-----\n", custom)
    assert '#define HAZE_TITLE_ID "HAZE00001"' in custom_render
    assert c.sizeof(Error) == 532 and c.sizeof(Status) == 600
    assert Status.downloaded_size.offset == 32 and Status.error_info.offset == 60
    result = {"urlValidation": "passed", "CAConfigValidation": "passed", "manifestValidation": "passed", "statusAbiArithmetic": "passed",
              "compilerRun": False, "consoleTested": False, "packageVerified": False}
    if args.package:
        result["packageSha256"] = config.verify_package(args.package)
        result["packageVerified"] = True
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
