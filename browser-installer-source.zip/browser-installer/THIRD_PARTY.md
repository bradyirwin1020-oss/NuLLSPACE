# Sources and licenses

New candidate source is licensed under **GPL-3.0-or-later**; see `COPYING`. Functional ABI declarations and implementation approaches were checked against these primary sources. No Sony proprietary SDK headers, Sony libraries, or browser package data are included.

- **PS5 Payload SDK**, John Törnblom and contributors: GPL-3.0-or-later. Required build dependency and kernel API declarations. Official v0.43: <https://github.com/ps5-payload-dev/sdk/tree/v0.43>. Firmware identifier reads `sdk_ps5_ver`: <https://github.com/ps5-payload-dev/sdk/blob/v0.43/crt/kernel.c>. Native AppInst exports: <https://github.com/ps5-payload-dev/sdk/blob/master/sce_stubs/libSceAppInstUtil.c>.
- **SDK kernel notification sample**, Copyright (C) 2023 John Törnblom, GPL-3.0-or-later: <https://github.com/ps5-payload-dev/sdk/blob/v0.43/samples/notify_debug/main.c>. The candidate's 3120-byte notification request layout and nonblocking call convention follow this official sample.
- **etaHEN**, LightningMods and contributors: GPL-3.0-or-later at the repository level. Native package ABI/status reference: <https://github.com/etaHEN/etaHEN/blob/main/PS5%20technical%20writeups/pkg-writeup.md>. API layouts in `src/appinst_abi.h` follow this documented ABI; new control flow is independently implemented. Related source reference inspected locally was the GPL-3.0 fork **OnionHEN**, <https://github.com/aydencharles/onionHEN/tree/b23ffe674b2de9f62fe634944c9230ff149d593a>.
- **BFpilot**, ItsBlurf / BFpilot contributors: MIT. Fresh worker initialization and firmware 11+ installer identity approach: <https://github.com/ItsBlurf/BFpilot/blob/main/src/pkg_worker_main.c>. The candidate is not a BFpilot binary or full copied implementation. To preserve attribution for the pattern, the author's full MIT notice is included below.
- **curl/libcurl**: curl license. Build dependency, no curl source bundled. <https://curl.se/docs/copyright.html>. PacBrew package specification: <https://github.com/ps5-payload-dev/pacbrew-repo/blob/main/curl/PKGBUILD>.
- **OpenSSL 3.x**: Apache-2.0. Build dependency for EVP SHA256 and curl TLS, no source bundled. <https://github.com/openssl/openssl/blob/master/LICENSE.txt>.
- **zlib**: zlib license. Transitive static dependency, no source bundled. <https://github.com/madler/zlib/blob/master/LICENSE>.
- **CA certificates**: supply an independently trusted PEM bundle at build time; preserve the provenance and notices of that bundle. The build recipe accepts the Ubuntu system CA trust bundle, whose contents include the Mozilla root certificate collection. Its licensing/provenance belongs with any redistributed build artifact.
- **WBrowser package**: <https://github.com/ps5xploit/WBrowser>. The user's supplied package is separately authored; this source license grants no rights to that package. Its redistribution license remains unverified, so it is not included or published.

## BFpilot MIT notice

MIT License

Copyright (c) 2024 ItsBlurf / BFpilot contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
