# Review against the exact SDK and payload

This review is static. It does not substitute for compiling the candidate or running an installation on PS5 13.42.

## Imports and layouts

The downloaded official SDK v0.43 archive was inspected directly. Its `target/include/ps5/kernel.h` matches all kernel function declarations used here, including the 16-byte caps and 32-byte attrs buffers. Socket APIs use `socklen_t`, `send`/`recv` return `ssize_t`, and pthread declarations match their usage. Its native stub libraries contain `sceAppInstUtilInitialize`, `sceAppInstUtilAppExists`, `sceAppInstUtilInstallByPackage`, `sceAppInstUtilGetInstallStatus`, and `sceKernelGetProcessName`.

The native AppInst declarations are manually supplied because the SDK stub is an export shim rather than a typed installer header. Struct layouts follow etaHEN's primary package-installation writeup and have C static assertions: metadata 48 bytes, package info 56, PlayGo 9984, error 532, and status 600, with downloaded-size offset 32 and error-info offset 60. Host ctypes arithmetic agrees. `AppExists(const char *, int *)` uses the documented native convention from flatz's installer source and the same symbol is present in PS5's SDK stub; its behavior on this firmware still requires native validation.

## Fresh process and timeout behavior

This ELF must be launched as a **fresh process** by the site's compatible ELF loader, not injected into an existing application. Only `getpid()` credentials are changed; no other process credentials are written. That identity remains in place until this worker exits. There is no restoration window, which avoids changing an AppInst peer's identity after initialization. The design must not be reused as an in-process plugin without a separate credential-lifecycle design.

Native initialization/query/submission/status calls are serialized by the main thread, each executed in a detached worker thread. A release/acquire atomic publishes the returned code and output structs only after the native call returns; the worker touches no shared arguments afterward. There is no unbounded `pthread_join`. A timeout ends this one-shot process with `_exit`; it does not restore or resume a hijacked host and does not cancel Sony's background installer. This process-exit bound does not promise recovery if a system service or kernel operation itself becomes uninterruptible.

Initialization and pre-submission query failure mean no package was submitted. Submission/status timeout is indeterminate: the service may have accepted the package. No duplicate submission is attempted, and the package is retained after every submission result, including playable. A per-title durable pending marker is exclusively created and fsynced immediately before submission. It survives process exit and prevents a subsequent visit from resubmitting; only confirmed native playable plus AppExists clears it. Polling has a 180-second nominal budget plus at most one in-flight 5-second native query and scheduling overhead.

## Package and download bounds

Every build uses a selected reviewed manifest. The original supplied package pin is preserved in `packages/original-WBrowser.json`. URL validation requires HTTPS, rejects embedded credentials/fragments/control or non-ASCII characters, and does not perform network I/O. The manifest constrains title/content-ID format, agreement between those IDs, SHA256 form, and a 64 MiB size ceiling. The optional local package check reads size, FIH magic, and SHA256 only. Internal package metadata/signatures must be verified by the package builder independently.

libcurl is configured for certificate and hostname validation, trusted CA data, HTTPS-only requests/redirects, HTTP error rejection, and bounded download/connect/low-speed time. The callback rejects any write exceeding the exact manifest size, hashes streaming bytes, and captures the four magic bytes across callback boundaries. Invariants keep the received count within the expected byte range. Failure deletes only that run's newly created partial file. A file lock and unique staging directory prevent concurrent workers from using the same package path.

## Readiness protocol evidence

The actual bundled etaHEN bootstrapper contains `/system_tmp/etaHEN/ready`, `hen_daemon.elf`, and `hen_util.elf`. Its embedded private loader contains literal `hen:ping` and `OK hen_elfldr 9020\n`. These were checked in the unpacked binary, rather than copying the OnionHEN source's different `onion:ping` branding. The candidate requires the exact response, live marker PIDs, and matching process names. A reachable TCP port by itself is insufficient.

## Remaining risks

- The native package ABI/API behavior, trusted CA acceptance, firmware identifier, and identity choice require console validation on 13.42. BFpilot's firmware 11+ identity approach is supporting evidence, not a successful test on this console.
- The SDK firmware identifier comes from libc's `sdk_ps5_ver`. A 13.42 console reporting a 13.40-family libc identifier is deliberately rejected. Broader support must not be inferred from a successful 13.42 test.
- Existing title-directory detection is deliberately conservative. It skips partial installs without claiming registration; a repair/migration needs separate explicit handling.
- `playable` plus title existence confirms the service considers the browser launchable. It does not prove all background activity has ended or that the package opens the intended website.
- A custom browser must use a separately validated manifest. Reusing the original title ID intentionally prevents automatic replacement of an existing original browser.
- The original package's author/license provenance is recorded separately from this candidate source. A separately rebuilt browser needs its own manifest. Static dependency notices and source obligations belong with a distributed ELF.
