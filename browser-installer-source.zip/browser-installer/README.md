# Haze browser installer candidate

This is a separate **source candidate**, not an enabled stage of the live PS5 autoloader. It has not been compiled or executed on a console in this workspace. The local Windows environment has no configured PS5 compiler, Make, or installed WSL distribution. A POSIX SDK build or a reviewed GitHub Actions build is required next.

The candidate creates a fresh, one-shot PS5 ELF process after etaHEN. It downloads and verifies the exact browser package supplied in this task, then calls the PS5's native package installation service. A `.pkg` is never sent to ELF loader port 9021.

## Behavior

1. Read the SDK's firmware identifier. Accept only libc SDK version `0x1342xxxx`. This targets the 13.42 test console and rejects every other/unknown SDK value. The SDK reads `sdk_ps5_ver` from libc; this is not an independent measurement of the Settings screen's firmware. A console on 13.42 whose libc reports the 13.40 family may be conservatively rejected.
2. If `/user/app/<configured title ID>` already exists, stop before waiting, downloading, changing identity, or initializing the native installer. The original manifest's ID is `MOUU12023`. Report **existing browser files found**, rather than claiming that Sony registration was checked. Never overwrite a partially installed title. For other storage locations, use the native `AppExists` query after initialization.
3. Otherwise wait up to 90 seconds for live `hen_daemon.elf` and `hen_util.elf` processes referenced by etaHEN ready markers, plus an exact private loader health reply: `hen:ping\n` → `OK hen_elfldr 9020\n`. This is specific to the repaired etaHEN 2.6B bundle used by this site. Other releases with different marker/process names are intentionally not accepted.
4. Set and verify only the fresh worker's installer identity, using the firmware 11+ AppInst auth ID `0x4801000000000013`. This uses SDK kernel APIs, not new firmware offsets. Initialize native AppInst with a 10-second bound. Existing-title queries have a 5-second bound.
5. Download from the configured direct **HTTPS** URL with certificate and hostname validation, HTTPS-only redirects, a 15-second connection limit, and a 300-second total download limit. The trusted PEM CA bundle is embedded at build time; TLS verification is never disabled.
6. Reject any download with a different size, FIH magic, or SHA256. Recheck etaHEN readiness and title existence immediately before submission. Submit once to `sceAppInstUtilInstallByPackage`, with a 15-second native-call bound.
7. A successful submission means **accepted**, not installed. Query `sceAppInstUtilGetInstallStatus` for up to 180 seconds. Only report **playable** when the native service reports `playable` and `AppExists` confirms the browser title. A timeout or failed query after submission reports **indeterminate/accepted pending**, retains the staged package, and never automatically resubmits.

The native status layout and return semantics still need console validation on 13.42. `playable` means the service considers the application launchable; it is not an assertion about every internal background operation. Bounding the worker does not cancel Sony's background installation or guarantee a hung system service can be recovered by this process.

## Exact package pin

| Property | Inspected value |
| --- | --- |
| Filename | `InternetBrowser-PS5M.pkg` |
| Size | `37,633,547` bytes |
| SHA256 | `90d29db230458acfd2e3332dc338afe6e63f3d0c0948517918286497c9ac17ca` |
| Magic | `7f 46 49 48` (`\x7fFIH`) |
| Title ID | `MOUU12023` |
| Content ID | `IV9999-MOUU12023_00-XXXXXXXXXXXXXXXX` |
| Initial browser destination | `https://ps5xploit.github.io/WBrowser/` |

The package is **not included, copied, uploaded, or rebuilt by this source candidate**. The author's WBrowser repository links this filename but did not expose a redistribution license when checked; that provenance is recorded in the original manifest. A build may select a direct author download URL or another HTTPS package host. The author's MediaFire landing page is HTML and is **not** a direct package URL; its response will fail the hash check.

Installing this unchanged package does not change its initial destination to the Haze site. The user can open the browser and enter `https://haze7714.github.io/Relapse-Exploit/`. The browser already survives restarts on the user's console, so existing installations should be skipped rather than reinstalled.

## Build

Use the official PS5 Payload SDK v0.43 and a compatible PacBrew dependency tree containing `libcurl` with OpenSSL and zlib. A current curl is required for `CURLOPT_CAINFO_BLOB` and HTTPS protocol string restrictions. The SDK's `prospero-pkg-config` supplies static dependency flags. Retain `SceIpmi`, `SceAppInstUtil`, `kernel_sys`, and pthread dependencies. Pin source/archive versions and verify asset digests in CI rather than using moving `latest` URLs.

```sh
export PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk
export LLVM_CONFIG=/usr/bin/llvm-config-18
python3 configure.py \
  --url 'https://YOUR-AUTHORIZED-HOST/InternetBrowser-PS5M.pkg' \
  --ca-bundle /etc/ssl/certs/ca-certificates.crt
make
```

The placeholder URL is not a live host and must be replaced. No URL is configured by default. `configure.py` embeds URL, CA certificates, and selected package metadata, not package bytes. Optionally `--package /path/to/InternetBrowser-PS5M.pkg` verifies a local package without copying it. The output is `build/haze-browser-installer.elf`. There is no deploy/install/publish Make target.

### A custom browser package

The original pin is preserved in `packages/original-WBrowser.json`. Do not edit it to pretend the original package opens a different site. For a separately built browser, create another JSON manifest with `size`, lowercase `sha256`, `titleId`, matching `contentId`, and printable ASCII `displayName`; include `initialUrl`, source, and licensing notes as provenance. Pass `--manifest path/to/custom.json` and preferably `--package path/to/custom.pkg` when configuring. The generator validates the metadata format and the optional local package size/magic/hash. It does not parse or rebuild a package, prove package signatures, or verify that its internal metadata matches the manifest; those are package-builder validation responsibilities.

A different title ID installs a separate browser and will not trigger the original `MOUU12023` skip. Keeping that original title ID will conservatively skip an existing original browser, so replacing it must be an explicit separate migration; this installer never removes or overwrites it. Do not advertise a custom package as tested until its build, metadata, startup destination, and first installation are verified.

Before distributing a compiled ELF, include the licenses and matching source obligations for the SDK and every linked static dependency. See [THIRD_PARTY.md](THIRD_PARTY.md).

## Verification performed here

```powershell
python tests/verify_candidate.py --package 'C:\Users\MUFASA\Downloads\InternetBrowser-PS5M.pkg'
```

Passed: rejection of HTTP/credential-bearing/malformed URLs; CA configuration shape and C string escaping; x86-64 status structure size/alignment arithmetic; supplied package size, SHA256, and FIH magic. These host checks do **not** prove C compilation, native API compatibility, download trust-chain acceptance on the PS5, or successful console installation. See `verification.json` for the recorded result.

Console validation still required: compile and inspect the ELF and its dependencies; verify harmless existing-title skip; test one first installation on a supported console with the title absent; confirm the home-screen browser opens and survives a normal restart; exercise a wrong hash and missing readiness without submission. Do not promote this stage to the live autoloader before the first-install path is verified.

## Local status and retained files

The worker prints fixed status messages, sends best-effort PS5 notifications for major/terminal states using the official SDK's documented kernel notification ABI, and writes its latest state to `/user/data/HazeBrowserInstaller/status.json` once staging is available. A notification request is not proof it was displayed. It opens no listening network service and exposes no remote install endpoint. A file lock prevents concurrent candidate processes. Each run creates a unique directory inside that staging root.

Before submission, the worker exclusively creates and fsyncs `/user/data/HazeBrowserInstaller/pending-<titleId>.json` with the package path and identity. This intent survives worker exit, so another visit cannot silently resubmit an unresolved background task. It is cleared only after native `playable` plus `AppExists` confirmation. Rejection, timeout, unknown results, and a staging-directory fsync failure retain the marker for separate resolution; no automatic retry occurs. Do not manually remove it until the previous native task is known to have ended. A pending marker with existing title files still prevents replacement; the conservative file-presence skip does not clear it.

After submission, including a confirmed `playable` result, the worker retains its staged package because the native service may still reference it. Cleanup must be a separate action after installation activity has stopped. Check the console's installation state before another attempt. No uninstall, firmware update, title overwrite, console restart, or deletion of unrelated files is performed.
